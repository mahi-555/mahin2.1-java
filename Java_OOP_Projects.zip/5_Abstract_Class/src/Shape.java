public abstract class Shape {
    abstract void draw();

    void info() {
        System.out.println("This is a shape");
    }
}