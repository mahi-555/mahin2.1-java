import java.util.Scanner;

public class ATM {
    private double balance = 5000;

    void deposit(double amt) {
        balance += amt;
        System.out.println("Deposited!");
    }

    void withdraw(double amt) {
        if(amt <= balance) {
            balance -= amt;
            System.out.println("Withdrawn!");
        } else {
            System.out.println("Insufficient Balance");
        }
    }

    void checkBalance() {
        System.out.println("Balance: " + balance);
    }

    public static void main(String[] args) {
        ATM a = new ATM();
        Scanner sc = new Scanner(System.in);

        while(true) {
            System.out.println("\n1.Deposit 2.Withdraw 3.Balance 4.Exit");
            int ch = sc.nextInt();

            switch(ch) {
                case 1:
                    System.out.print("Amount: ");
                    a.deposit(sc.nextDouble());
                    break;
                case 2:
                    System.out.print("Amount: ");
                    a.withdraw(sc.nextDouble());
                    break;
                case 3:
                    a.checkBalance();
                    break;
                case 4:
                    System.exit(0);
            }
        }
    }
}