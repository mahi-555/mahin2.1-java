public class Car {
    String brand;
    int speed;

    void showInfo() {
        System.out.println("Brand: " + brand);
        System.out.println("Speed: " + speed);
    }
}