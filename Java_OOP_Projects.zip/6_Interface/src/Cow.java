public class Cow implements Animal {
    public void makeSound() {
        System.out.println("Cow says Moo");
    }
}