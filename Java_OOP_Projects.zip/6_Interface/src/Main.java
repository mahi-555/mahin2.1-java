public class Main {
    public static void main(String[] args) {
        Cow c = new Cow();
        c.makeSound();
    }
}