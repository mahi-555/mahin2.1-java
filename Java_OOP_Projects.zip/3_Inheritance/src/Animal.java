public class Animal {
    protected String category = "Mammal";

    void show() {
        System.out.println("This is an animal.");
    }
}