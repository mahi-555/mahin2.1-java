package ict.22.ClassNames;

public class SumClass {
    public static double sumSeries() {
        double i = 1.0, sum = 0.0;
        do {
            sum += i;
            i -= 0.1;
        } while (i >= 0.1);
        return sum;
    }
}
