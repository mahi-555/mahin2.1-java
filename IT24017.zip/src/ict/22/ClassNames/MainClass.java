package ict.22.ClassNames;

public class MainClass {
    public static void main(String[] args){
        CustomPrintClass p=new CustomPrintClass();

        p.pr("Sum = "+SumClass.sumSeries());
        p.pr("GCD = "+DivisorMultipleClass.gcd(12,18));
        p.pr("LCM = "+DivisorMultipleClass.lcm(12,18));

        p.pr("Decimal 25 to Binary: "+NumberConversionClass.decToBin(25));
        p.pr("Binary 11001 to Decimal: "+NumberConversionClass.binToDec("11001"));
    }
}
