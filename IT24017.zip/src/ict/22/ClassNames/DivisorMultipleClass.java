package ict.22.ClassNames;

public class DivisorMultipleClass {
    public static int gcd(int a, int b) {
        while(b != 0){
            int t=b;
            b=a%b;
            a=t;
        }
        return a;
    }
    public static int lcm(int a, int b){
        return (a*b)/gcd(a,b);
    }
}
