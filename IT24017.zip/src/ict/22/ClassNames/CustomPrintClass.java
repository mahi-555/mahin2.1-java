package ict.22.ClassNames;

public class CustomPrintClass {
    public void pr(String msg){
        System.out.println(msg);
    }
}
