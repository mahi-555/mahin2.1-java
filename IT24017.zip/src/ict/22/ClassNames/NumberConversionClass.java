package ict.22.ClassNames;

public class NumberConversionClass {
    public static String decToBin(int n){ return Integer.toBinaryString(n); }
    public static String decToOct(int n){ return Integer.toOctalString(n); }
    public static String decToHex(int n){ return Integer.toHexString(n); }
    public static int binToDec(String b){ return Integer.parseInt(b,2); }
    public static int octToDec(String o){ return Integer.parseInt(o,8); }
    public static int hexToDec(String h){ return Integer.parseInt(h,16); }
}
